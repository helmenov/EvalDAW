/*-------------------------------------------------------------------
 * $Id: picola.c,v 1.3 2006/11/30 09:51:58 ikeda Exp $
 *
 * Time domain harmonic scaling by
 * Pointer Inteval Controled OverLap and ADD (PICOLA) Method
 *		C version by IKEDA Mikio
 *		original argolithm is developed by MORITA Naotaka
 *		about detail, see original paper.
 *-------------------------------------------------------------------
 * Usage
 *  PICOLA <source signal>
 *         <companded (destination) signal>
 *	   <compansion ratio>
 *
 * Last three arguments can be abbriviated.
 *
 * Note
 *   The procedure is NOT exactly identical to that of 
 *   http://keizai.yokkaichi-u.ac.jp/%7Eikeda/research/picola.html
 *-------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "wavfile_simple.h"
#include "picola_tdhs.h"

#define PIT_MAX_Hz 250 /* in Hz */
#define PIT_MIN_Hz 60  /* in Hz */

/*----*/

int
main(int argc, char *argv[])
{
  long   *is;       /* input signal buffer */
  double rate;      /* compansion rate
		     * case of less than 1.0 compression,
		     * case of greater than 1.0 expansion
		     */

  double rcomp;	      /* internal modified compansion ratio */
  double sl;
  double err = 0.0;  /* compansion rate error estimate */
  int pitmin;        /* minimal pitch period (250Hz for 8kHz) */
  int pitmax;        /* maximal pitch period (62.5Hz for 8kHz)*/
  int pitch;	/* detected pitch period */
  int length;
  int nread;	/* number of read samples (from file) */
  int n_rest;

  int lcp;	/* number of copy samples */
  int i, lw;	/* loop counter */
  int point;
  int total;    /* total frame length */

  int t_write = 0;	/* processed speech samples */
  int n_read, n_write;
  void usage(char *);

  waveFormat *srcfmt, *dstfmt;

  char  srcfile[256], dstfile[256];
  FILE  *srcfd, *dstfd;
  /*
   *--------------- 
   * get arguments from command line or stdin
   */

  if (argc < 4) {
    usage(argv[0]);
  }
  if (argc >= 2) {
    strncpy(srcfile, argv[1], 255);
  }else{
    printf("source signal file    = ");
    scanf("%255s", srcfile);
  }

  if (argc >= 3) {
    strncpy(dstfile, argv[2], 255);
  }else{
    printf("companded signal file = ");
    scanf("%255s", dstfile);
  }

  if (argc >= 4) {
    rate = atof(argv[3]);
  }else{
    printf("compansion rate       = ");
    scanf("%lf", &rate);
  }

  /*
   *-------------- error check and initialize ---------------------
   */
  if (rate <= 0.0 || rate == 1.0) {
    printf("illeagal compansion rate !!\n");
    return 0;
  }
  if (rate > 1.0) {
    rcomp = 1.0  / (rate - 1.0); /* */
  }else if (rate > 0) {
    rcomp = rate / (1.0 - rate);
  }else {
    printf("Error from %s: illeagal compansion rate!\n", argv[0]);
    return 0;
  }
  /* open files */
  srcfd = fopen(srcfile,"rb");
  srcfmt = readWaveHeader(srcfd);
  if (srcfmt->channels != 1) {
    printf("Error from %s : Cannot handle multi channel audio data!\n", argv[0]);
    return 0;
  }
  dstfmt = copyWaveFormat(srcfmt);
  dstfmt->data_size = 0;
  pitmin = srcfmt->frequency / PIT_MAX_Hz;
  pitmax = srcfmt->frequency / PIT_MIN_Hz;
  length = pitmax;
  total  = pitmax * 2;
  is = (long *)malloc(sizeof(*is)*total);
  if (is == NULL) {
    printf("Error from %s : malloc failed!\n", argv[0]);
    return 0;
  }

  dstfd = fopen(dstfile,"wb");
  writeWaveHeader(dstfmt, dstfd); /* write header and seek head */

  /*
   *------------------- body ---------------
   */

  /* read initial frame data */
  nread = readwav(is, total, srcfmt, srcfd);
  n_rest = total - nread;

  while (n_rest == 0) {

    /*---- pitch extraction ----*/

    pitch = amdfpitch(pitmin, pitmax, length, is);

    /*---- compensate compansion rate ----*/

    sl = (double)pitch * rcomp;
    lcp = sl;
    err += lcp - sl;

    if (err >= 0.5) {	
      --lcp;
      err -= 1.0;
    }else if (err <= -0.5) {
      ++lcp;
      err += 1.0;
    }
    if (rate < 1.0) {
      ola(pitch, is, is+pitch);
      point = total - pitch;
      for (i = 0; i < point; ++i) {  /* remove Tp length wavelet */ 
	is[i] = is[i+pitch];
      }
      if (pitch != (nread = readwav(is+point, pitch, srcfmt, srcfd))) {
	n_rest = nread - pitch;
	break;
      }
    }else{
      writewav(is, pitch, dstfmt, dstfd); /* add Tp length wavelet */
      t_write += pitch;
      ola(pitch, is+pitch, is);
    }

    /*-------------------------------------------------------------------
     * Picola pointer interval control stage (common part)
     * Read & Write lcp length samples
     *
     *               expansion  compression
     * Read           lcp        Tp+lcp
     * Write          lcp+Tp     lcp
     *
     * already read   0          Tp
     * already wrote  Tp         0
     *
     */

    n_read  = 0;  /* number of total read  samples */
    n_write = 0;  /* number of total wrote samples */
    n_rest  = 0;
    /* output 'lcp' samples using limited length buffer */

    for (lw = lcp; lw >= total; lw -= total) {
      writewav(is, total, dstfmt, dstfd);
      t_write += total;
      nread   = readwav(is, total, srcfmt, srcfd);
      n_write += total;
      n_read  += nread;
      if (nread != total) {
	n_rest = nread - total;
	break;
      }
    }
    if (n_rest == 0) {
      writewav(is, lw, dstfmt, dstfd);
      t_write += lw;
      n_write += lw;           /* fool proof */
      point = total - lw;
      for (i = 0; i < point; ++i) {
	is[i] = is[i+lw];
      }
      nread = readwav(is + point, lw, srcfmt, srcfd);
      n_read += nread;
      if (nread != lw) {
	n_rest = nread - lw;
	break;
      }
    }
  }
  fclose(srcfd);

  /* flush left data within input buffer */
  n_rest += total;
  if (n_rest > 0) {
    writewav(is, n_rest, dstfmt, dstfd);
    t_write += n_rest;
  }

  dstfmt->data_size = t_write;
  writeWaveHeader(dstfmt, dstfd);
  fclose(dstfd);

  return 1;
}

/*-------------------------------------------------------------------
 * picola OverLap and add stage 
 */

void
ola(const int tp, long is1[], long is2[])
{
  int i;
  double ss, w, step;
  step = 1.0/tp;
  for (i = 0; i < tp; ++i) {
    w = step * i;
    ss = (double)is1[i] * (1.0-w) + (double)is2[i] * w;
    is2[i] = ss;
  }
  return;
}

/*----*/
void
usage(char *arg0)
{
  printf("\nUsage : \n");
  printf("  %s <input wav file> <output wav file> <compansion ratio>\n\n",
	 arg0);
}
