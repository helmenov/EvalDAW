/* $Id: wavfile_simple.h,v 1.1 2004/11/21 14:11:02 mikio Exp $ */
/* Header file for Simple Wav format audio file input output routines */

#ifndef _WAVEFILE_SIMPLE_H
#define _WAVEFILE_SIMPLE_H

#include <stdio.h>

typedef struct waveFormat{
  long format;
  unsigned long  frequency;
  unsigned short channels;
  unsigned short bytes_per_sample;
  unsigned short block_align;
  unsigned long  data_size;
  unsigned long  head_skip;
  unsigned long  last_position;
} waveFormat;

#define WAVE_FORMAT_UNKNOWN             (0x0000)
#define WAVE_FORMAT_PCM                 (0x0001) 
#define WAVE_FORMAT_ADPCM               (0x0002)
#define WAVE_FORMAT_ALAW                (0x0006)
#define WAVE_FORMAT_MULAW               (0x0007)
#define WAVE_FORMAT_OKI_ADPCM           (0x0010)
#define WAVE_FORMAT_IMA_ADPCM           (0x0011)
#define WAVE_FORMAT_DIGISTD             (0x0015)
#define WAVE_FORMAT_DIGIFIX             (0x0016)
#define IBM_FORMAT_MULAW                (0x0101)
#define IBM_FORMAT_ALAW                 (0x0102)
#define IBM_FORMAT_ADPCM                (0x0103)

waveFormat *readWaveHeader(FILE *);
waveFormat *copyWaveFormat(waveFormat *);
int        readwav(long *, int, waveFormat *, FILE *);
void       writeWaveHeader(waveFormat *, FILE *);
int        writewav(long *, int, waveFormat *, FILE *);
int        seekwav(int, int, FILE *);
void       write_intel_ushort(int, FILE *);
void       write_intel_ulong(unsigned long, FILE *);
unsigned   short read_intel_ushort(FILE *);
unsigned   long read_intel_ulong(FILE *);

#define SIZE_ID       4
#define SIZE_LONG     4
#define SIZE_SHORT    2
#define BITS_PER_BYTE 8

#endif
