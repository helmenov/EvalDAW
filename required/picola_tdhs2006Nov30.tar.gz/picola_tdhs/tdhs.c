/*-------------------------------------------------------------------
 * $Id: tdhs.c,v 1.1 2004/11/21 14:06:43 mikio Exp ikeda $
 *
 * Time Domain Harmonic Scaling (TDHS)
 *		C version by IKEDA Mikio
 *		about detail, see original paper.
 *-------------------------------------------------------------------
 * Usage
 *  tdhs <source signal>
 *       <companded (destination) signal>
 *	 <compansion ratio>
 * Note
 *   refer
 *   http://keizai.yokkaichi-u.ac.jp/%7Eikeda/research/picola.html
 *-------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "wavfile_simple.h"
#include "picola_tdhs.h"

#define PIT_MAX_Hz 250
#define PIT_MIN_Hz 60

/*----*/


int
main(int argc, char *argv[])
{
  long *is;             /* input signal buffer */
  long *os;             /* output signal buffer */
  int n_ratio;
  int m_ratio;     /* n/m compansion */
  int pitmin;      /* minimal pitch period (250Hz for_mr 8kHz) */
  int pitmax;      /* maximal pitch period (62.5Hz for 8kHz)*/
  int pitch;	   /* detected pitch period */
  int length;      /* at least pitmax*(n or m) is required */
  int nread;	   /* number of read samples (from file) */
  int total;       /* total frame length */
  int t_write = 0; /* processed speech samples */
  int offset;
  int point;
  int i, lw;
  int get_mr(char *), get_nr(char *);
  void usage(char *);
  void tdhs_ola(long int [], long int [], const int, const int, const int);

  waveFormat *srcfmt, *dstfmt;

  char  srcfile[256], dstfile[256], ratio[256];
  FILE  *srcfd, *dstfd;

  /*
   *--------------- 
   * get arguments from command line or stdin
   */

  if (argc < 4) {
    usage(argv[0]);
  }
  if (argc >= 2) {
    strncpy(srcfile, argv[1], 255);
  }else{
    printf("source signal file    = ");
    scanf("%255s", srcfile);
  }

  if (argc >= 3) {
    strncpy(dstfile, argv[2], 255);
  }else{
    printf("companded signal file = ");
    scanf("%255s", dstfile);
  }

  if (argc >= 4) {
    n_ratio = get_nr(argv[3]);
    m_ratio = get_mr(argv[3]);
  }else{
    printf("compansion rate (give n/m) = ");
    scanf("%255s", &ratio);
    n_ratio = get_nr(ratio);
    m_ratio = get_mr(ratio);
  }
  if (n_ratio <= 0 || m_ratio <= 0) {
    printf("Error from : Wrong compansion specification(s)!\n", argv[0]);
    return 0;
  }
  /*
   *-------------- error check and initialize ---------------------
   */
  /* open files */
  srcfd = fopen(srcfile,"rb");
  srcfmt = readWaveHeader(srcfd);
  if (srcfmt->channels != 1) {
    printf("Error from %s : Cannot handle multi channel audio data!\n", argv[0]);
    return 0;
  }
  dstfmt = copyWaveFormat(srcfmt);
  dstfmt->data_size = 0;
  pitmin = srcfmt->frequency / PIT_MAX_Hz;
  pitmax = srcfmt->frequency / PIT_MIN_Hz;

  if (n_ratio > m_ratio) {
    total  = pitmax * (n_ratio*2-m_ratio);
    offset = (n_ratio - m_ratio) * pitmax;
  }else{
    total  = pitmax * m_ratio;
    offset = 0;
  }
  length = total - offset - pitmax;
  is = (long *)malloc(sizeof(*is)*total);
  os = (long *)malloc(sizeof(*os)*n_ratio*pitmax);
  if (is == NULL || os == NULL) {
    printf("Error from %s : malloc failed!\n", argv[0]);
    return 0;
  }
  dstfd = fopen(dstfile,"wb");
  writeWaveHeader(dstfmt, dstfd); /* write header and seek head */

  /*
   *------------------- body ---------------
   */

  t_write = 0;
  
  /* read initial frame data */

  nread = readwav(is+offset, total-offset, srcfmt, srcfd);
  for (i = 0; i < offset; ++i) is[i] = 0; /* fill head 0 */
  while (nread != 0) {
    pitch = amdfpitch(pitmin, pitmax, length, is+offset);
    tdhs_ola(is+offset, os, n_ratio, m_ratio, pitch);
    writewav(os, n_ratio * pitch, dstfmt, dstfd);
    t_write += n_ratio * pitch;
    /* frame shift */
    lw = m_ratio * pitch;
    point = total - lw;
    for (i = 0; i < point; ++i) is[i] = is[i+lw];
    nread = readwav(is+point, lw, srcfmt, srcfd);
  }
  fclose(srcfd);
  dstfmt->data_size = t_write;
  writeWaveHeader(dstfmt, dstfd);
  fclose(dstfd);
  return 1;
}

void
tdhs_ola(long is[], long os[], const int n_r, const int m_r, const int tp)
{
  int i, len, off;
  double w, ss, step;

  len = n_r * tp;  /* output length */
  off = (m_r - n_r) * tp;
  step = 1.0 / len;
  for (i = 0; i < len; ++i) {
    w = step * i;
    ss = is[i]*(1.0-w) +is[i+off] * w; 
    os[i] = ss;
  }
}

/*----*/

int
get_nr(char *str)
{
  char *si;
  int n_r;
  for (si = str; *si != '\0'; ++si) {
    if (*si == '/') {
      *si = '\0';
      n_r = atoi(str);
      *si = '/';
      return n_r;
    }
  }
  return 0;
}

int
get_mr(char *str)
{
  char *si;
  int m_r;
  for (si = str; *si != '\0'; ++si) {
    if (*si == '/') {
      m_r = atoi(si+1);
      return m_r;
    }
  }
  return 0;
}

void
usage(char *arg0)
{
  printf("\nUsage : \n");
  printf("  %s <input wav file> <output wav file> <compansion ratio>\n",
	 arg0);
  printf("Note: give compansion ratio as n/m (both 'n' and 'm' should be integer values).\n\n");
}
