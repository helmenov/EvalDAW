/*-------------------------------------------------------------------
 * $Id: pitch.c,v 1.1 2004/11/21 14:04:53 mikio Exp $
 *
 * Periodicity detection routines for either PICOLA or TDHS.
 *
 */

/*-------------------------------------------------------------------
 * periodicity extraction using covariance method 
 * (Slow)
 */

#include <math.h>
#include "picola_tdhs.h"

int covpitch(const int pitmin, const int pitmax, const int length, long is[])
{
  int i, j, pitch;
  double covst, covs0t, covmax = 0.0, s;

  pitch = pitmin;
  for (i = pitmin; i <= pitmax; ++i) {
    covst = 0.0;
    covs0t = 0.0;
    for (j = 0; j < length; j++) {
      s = (double)is[i+j];
      covs0t += s * s;
      covst += (double)is[j] * s;
    }
    covst = covst / sqrt(covs0t);
    if (covst >= covmax) {
      covmax = covst;
      pitch = i;
    }
  }
  return(pitch);
}

/*-------------------------------------------------------------------
 * periodicity extration using Averaged Mean Difference Function (AMDF)
 * 
 * The extracted value is NOT pitch period in precise meaning.
 *
 */

int amdfpitch(const int pitmin, const int pitmax, const int length, long is[])
{
  int i, j, diff, acc, accmin, pitch;

  pitch = pitmin;
  accmin = 0;
  for (j = 0; j < length; ++j) {
    diff = is[j+pitmin] - is[j];
    if (diff > 0) {
      accmin += diff;
    }else{
      accmin -= diff;
    }
  }
  for (i = pitmin + 1; i <= pitmax; ++i) {
    acc = 0;
    for (j = 0; j < length; ++j) {
      diff = is[i+j] - is[j];
      if (diff > 0) {
	acc += diff;
      }else{
	acc -= diff;
      }
    }
    if (acc < accmin) {
      accmin = acc;
      pitch = i;
    }
  }
  return pitch;
}
