/* $Id: picola_tdhs.h,v 1.1 2004/11/21 14:04:35 mikio Exp $ */
/* OverLap and Add */

void ola(const int, long [], long []);

/* pitch extraction routines */

int  amdfpitch(const int, const int, const int, long []);
int  covpitch(const int, const int, const int, long []);
